export const ApiKey = 'af30ad5d737fa343f42cb8cba9ab4690';
export const ApiBase = 'http://api.openweathermap.org/';